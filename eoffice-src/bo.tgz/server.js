'use strict';
const http = require('http'), crypto = require('crypto'), fs = require('fs');
const { DatabaseSync } = require('node:sqlite');
const DIR = process.env.DATA_DIR || './data';
fs.mkdirSync(DIR, { recursive: true });
const db = new DatabaseSync(DIR + '/office.db');
db.exec(`PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, name TEXT, role TEXT, pw TEXT, must INTEGER DEFAULT 0, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS sess(t TEXT PRIMARY KEY, uid INTEGER, exp INTEGER);
CREATE TABLE IF NOT EXISTS comm(id INTEGER PRIMARY KEY, dir TEXT, no TEXT, date TEXT, party TEXT, subject TEXT, mode TEXT, ref TEXT, status TEXT DEFAULT 'Open', assigned INTEGER, by INTEGER, at TEXT);
CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY, no TEXT, title TEXT, status TEXT DEFAULT 'Open', holder INTEGER, by INTEGER, at TEXT);
CREATE TABLE IF NOT EXISTS moves(id INTEGER PRIMARY KEY, fid INTEGER, frm INTEGER, too INTEGER, note TEXT, due TEXT, at TEXT);
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY, date TEXT, type TEXT, head TEXT, party TEXT, amount REAL, mode TEXT, narr TEXT, by INTEGER, at TEXT);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, at TEXT, uid INTEGER, act TEXT);`);
const now = () => new Date().toISOString();
const hash = (p, s = crypto.randomBytes(16).toString('hex')) => s + ':' + crypto.scryptSync(p, s, 32).toString('hex');
const check = (p, h) => { const [s, x] = h.split(':'); const y = crypto.scryptSync(p, s, 32).toString('hex'); return crypto.timingSafeEqual(Buffer.from(x), Buffer.from(y)); };
if (!db.prepare('SELECT 1 FROM users').get()) {
  const pw = crypto.randomBytes(6).toString('base64url');
  db.prepare('INSERT INTO users(username,name,role,pw,must) VALUES(?,?,?,?,1)').run('consultbanerjee', 'Administrator', 'admin', hash(pw));
  fs.writeFileSync(DIR + '/INITIAL_ADMIN_PASSWORD.txt', 'username: consultbanerjee\npassword: ' + pw + '\n(change at first login; delete this file afterwards)\n');
  console.log('Initial admin created; see ' + DIR + '/INITIAL_ADMIN_PASSWORD.txt');
}
const audit = (u, a) => db.prepare('INSERT INTO audit(at,uid,act) VALUES(?,?,?)').run(now(), u ? u.id : null, a);
const fails = new Map();
const send = (res, c, o, h = {}) => { res.writeHead(c, Object.assign({ 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin' }, h)); res.end(JSON.stringify(o)); };
const body = req => new Promise((ok, no) => { let b = ''; req.on('data', d => { b += d; if (b.length > 200000) { req.destroy(); no(); } }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { ok({}); } }); });
const user = req => { const m = /(?:^|; )s=([a-f0-9]{48})/.exec(req.headers.cookie || ''); if (!m) return null; const r = db.prepare('SELECT u.id,u.username,u.name,u.role,u.must FROM sess s JOIN users u ON u.id=s.uid WHERE s.t=? AND s.exp>? AND u.active=1').get(m[1], Date.now()); return r || null; };
const str = (v, n = 300) => String(v == null ? '' : v).slice(0, n).trim();
const FY = () => { const d = new Date(Date.now() + 19800000), y = d.getUTCFullYear(), m = d.getUTCMonth(); const a = m >= 3 ? y : y - 1; return a + '-' + String(a + 1).slice(2); };
const nextNo = (tbl, pre) => { const p = pre + '/' + FY() + '/'; const r = db.prepare('SELECT COUNT(*) c FROM ' + tbl + ' WHERE no LIKE ?').get(p + '%'); return p + String(r.c + 1).padStart(4, '0'); };

const routes = {
  'POST /api/login': async (req, res) => {
    const ip = req.socket.remoteAddress, f = fails.get(ip) || { n: 0, t: 0 };
    if (f.n >= 8 && Date.now() - f.t < 600000) return send(res, 429, { error: 'Too many attempts. Try again after 10 minutes.' });
    const b = await body(req), u = db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(str(b.username, 60).toLowerCase());
    if (!u || !check(str(b.password, 200), u.pw)) { fails.set(ip, { n: f.n + 1, t: Date.now() }); return send(res, 401, { error: 'Wrong user name or password.' }); }
    fails.delete(ip);
    const t = crypto.randomBytes(24).toString('hex');
    db.prepare('INSERT INTO sess VALUES(?,?,?)').run(t, u.id, Date.now() + 12 * 3600000);
    audit(u, 'login');
    send(res, 200, { ok: 1, must: u.must }, { 'Set-Cookie': 's=' + t + '; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=43200' });
  },
  'POST /api/logout': async (req, res, u) => { const m = /s=([a-f0-9]{48})/.exec(req.headers.cookie || ''); if (m) db.prepare('DELETE FROM sess WHERE t=?').run(m[1]); audit(u, 'logout'); send(res, 200, { ok: 1 }, { 'Set-Cookie': 's=; Max-Age=0; Path=/' }); },
  'GET /api/me': async (req, res, u) => send(res, 200, u),
  'POST /api/password': async (req, res, u) => {
    const b = await body(req), row = db.prepare('SELECT pw FROM users WHERE id=?').get(u.id);
    if (!check(str(b.old, 200), row.pw)) return send(res, 400, { error: 'Current password is wrong.' });
    const n = str(b.new, 200); if (n.length < 8) return send(res, 400, { error: 'New password must be at least 8 characters.' });
    db.prepare('UPDATE users SET pw=?,must=0 WHERE id=?').run(hash(n), u.id); audit(u, 'password changed'); send(res, 200, { ok: 1 });
  },
  'GET /api/users': async (req, res, u) => send(res, 200, db.prepare('SELECT id,username,name,role,active FROM users ORDER BY name').all().filter(x => u.role === 'admin' || x.active)),
  'POST /api/users': async (req, res, u) => {
    if (u.role !== 'admin') return send(res, 403, { error: 'Admin only.' });
    const b = await body(req), un = str(b.username, 40).toLowerCase().replace(/[^a-z0-9._]/g, ''), pw = str(b.password, 100);
    if (!un || !str(b.name) || pw.length < 8) return send(res, 400, { error: 'Name, user name and an 8+ character password are needed.' });
    const role = ['admin', 'staff', 'accounts'].includes(b.role) ? b.role : 'staff';
    try { db.prepare('INSERT INTO users(username,name,role,pw,must) VALUES(?,?,?,?,1)').run(un, str(b.name, 80), role, hash(pw)); } catch (e) { return send(res, 400, { error: 'User name already exists.' }); }
    audit(u, 'user added ' + un); send(res, 200, { ok: 1 });
  },
  'POST /api/users/toggle': async (req, res, u) => { if (u.role !== 'admin') return send(res, 403, { error: 'Admin only.' }); const b = await body(req); if (b.id === u.id) return send(res, 400, { error: 'You cannot deactivate yourself.' }); db.prepare('UPDATE users SET active=1-active WHERE id=?').run(+b.id); audit(u, 'user toggled ' + b.id); send(res, 200, { ok: 1 }); },
  'GET /api/summary': async (req, res, u) => send(res, 200, {
    inOpen: db.prepare("SELECT COUNT(*) c FROM comm WHERE dir='IN' AND status!='Closed'").get().c,
    outOpen: db.prepare("SELECT COUNT(*) c FROM comm WHERE dir='OUT' AND status!='Closed'").get().c,
    myFiles: db.prepare("SELECT COUNT(*) c FROM files WHERE holder=? AND status!='Closed'").get(u.id).c,
    allFiles: db.prepare("SELECT COUNT(*) c FROM files WHERE status!='Closed'").get().c,
    mine: db.prepare("SELECT COUNT(*) c FROM comm WHERE assigned=? AND status!='Closed'").get(u.id).c,
    bal: u.role === 'staff' ? null : db.prepare("SELECT COALESCE(SUM(CASE WHEN type='Receipt' THEN amount ELSE -amount END),0) b FROM ledger").get().b
  }),
  'GET /api/comm': async (req, res, u, q) => send(res, 200, db.prepare("SELECT c.*,a.name an FROM comm c LEFT JOIN users a ON a.id=c.assigned WHERE (?='' OR c.dir=?) ORDER BY c.id DESC LIMIT 500").all(str(q.get('dir'), 3), str(q.get('dir'), 3))),
  'POST /api/comm': async (req, res, u) => {
    const b = await body(req), dir = b.dir === 'OUT' ? 'OUT' : 'IN'; if (!str(b.subject) || !str(b.party)) return send(res, 400, { error: 'Party and subject are required.' });
    const no = nextNo('comm', dir === 'IN' ? 'INW' : 'OUT'), d = /^\d{4}-\d\d-\d\d$/.test(b.date) ? b.date : now().slice(0, 10);
    db.prepare('INSERT INTO comm(dir,no,date,party,subject,mode,ref,assigned,by,at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(dir, no, d, str(b.party, 150), str(b.subject, 400), str(b.mode, 30), str(b.ref, 100), +b.assigned || u.id, u.id, now());
    audit(u, 'comm ' + no); send(res, 200, { ok: 1, no });
  },
  'POST /api/comm/status': async (req, res, u) => { const b = await body(req); if (!['Open', 'In progress', 'Replied', 'Closed'].includes(b.status)) return send(res, 400, { error: 'Bad status.' }); db.prepare('UPDATE comm SET status=? WHERE id=?').run(b.status, +b.id); audit(u, 'comm ' + b.id + ' -> ' + b.status); send(res, 200, { ok: 1 }); },
  'GET /api/files': async (req, res) => send(res, 200, db.prepare('SELECT f.*,h.name hn FROM files f LEFT JOIN users h ON h.id=f.holder ORDER BY f.id DESC LIMIT 500').all()),
  'POST /api/files': async (req, res, u) => { const b = await body(req); if (!str(b.title)) return send(res, 400, { error: 'File title is required.' }); const no = nextNo('files', 'FILE'); db.prepare('INSERT INTO files(no,title,holder,by,at) VALUES(?,?,?,?,?)').run(no, str(b.title, 300), u.id, u.id, now()); audit(u, 'file ' + no); send(res, 200, { ok: 1, no }); },
  'POST /api/files/move': async (req, res, u) => {
    const b = await body(req), f = db.prepare('SELECT * FROM files WHERE id=?').get(+b.id);
    if (!f) return send(res, 404, { error: 'No such file.' }); if (f.holder !== u.id && u.role !== 'admin') return send(res, 403, { error: 'Only the person holding the file can move it.' });
    const to = db.prepare('SELECT id FROM users WHERE id=? AND active=1').get(+b.to); if (!to) return send(res, 400, { error: 'Choose a person.' });
    db.prepare('INSERT INTO moves(fid,frm,too,note,due,at) VALUES(?,?,?,?,?,?)').run(f.id, f.holder, to.id, str(b.note, 500), /^\d{4}-\d\d-\d\d$/.test(b.due) ? b.due : '', now());
    db.prepare('UPDATE files SET holder=? WHERE id=?').run(to.id, f.id); audit(u, 'file ' + f.no + ' moved to ' + to.id); send(res, 200, { ok: 1 });
  },
  'POST /api/files/close': async (req, res, u) => { const b = await body(req); db.prepare("UPDATE files SET status=CASE WHEN status='Closed' THEN 'Open' ELSE 'Closed' END WHERE id=? AND (holder=? OR ?='admin')").run(+b.id, u.id, u.role); audit(u, 'file toggle ' + b.id); send(res, 200, { ok: 1 }); },
  'GET /api/trail': async (req, res, u, q) => send(res, 200, db.prepare('SELECT m.*,a.name fn,b.name tn FROM moves m LEFT JOIN users a ON a.id=m.frm LEFT JOIN users b ON b.id=m.too WHERE fid=? ORDER BY m.id').all(+q.get('id'))),
  'GET /api/ledger': async (req, res, u) => u.role === 'staff' ? send(res, 403, { error: 'Accounts access needed.' }) : send(res, 200, db.prepare('SELECT * FROM ledger ORDER BY date DESC,id DESC LIMIT 500').all()),
  'POST /api/ledger': async (req, res, u) => {
    if (u.role === 'staff') return send(res, 403, { error: 'Accounts access needed.' });
    const b = await body(req), a = Math.round(parseFloat(b.amount) * 100) / 100; if (!(a > 0) || !str(b.head)) return send(res, 400, { error: 'Head and a positive amount are required.' });
    db.prepare('INSERT INTO ledger(date,type,head,party,amount,mode,narr,by,at) VALUES(?,?,?,?,?,?,?,?,?)').run(/^\d{4}-\d\d-\d\d$/.test(b.date) ? b.date : now().slice(0, 10), b.type === 'Payment' ? 'Payment' : 'Receipt', str(b.head, 100), str(b.party, 150), a, str(b.mode, 30), str(b.narr, 300), u.id, now()); audit(u, 'ledger ' + a); send(res, 200, { ok: 1 });
  },
  'GET /api/audit': async (req, res, u) => u.role !== 'admin' ? send(res, 403, { error: 'Admin only.' }) : send(res, 200, db.prepare('SELECT a.at,a.act,u.name FROM audit a LEFT JOIN users u ON u.id=a.uid ORDER BY a.id DESC LIMIT 300').all())
};
const PUBLIC = new Set(['POST /api/login']);
const html = fs.readFileSync(__dirname + '/index.html');
http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x'), key = req.method + ' ' + url.pathname;
    if (req.method === 'GET' && !url.pathname.startsWith('/api/')) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Frame-Options': 'DENY', 'Content-Security-Policy': "default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src 'self' data:" }); return res.end(html); }
    const h = routes[key]; if (!h) return send(res, 404, { error: 'Not found' });
    if (req.method === 'POST' && req.headers['x-req'] !== '1') return send(res, 403, { error: 'Bad request' });
    const u = user(req);
    if (!PUBLIC.has(key) && !u) return send(res, 401, { error: 'Please sign in.' });
    if (u && u.must && !['POST /api/password', 'GET /api/me', 'POST /api/logout'].includes(key)) return send(res, 403, { error: 'Change your password first.' });
    await h(req, res, u, url.searchParams);
  } catch (e) { console.error(e); send(res, 500, { error: 'Server error' }); }
}).listen(3200, '0.0.0.0', () => console.log('BMS eOffice on 3200'));
setInterval(() => db.prepare('DELETE FROM sess WHERE exp<?').run(Date.now()), 3600000);
